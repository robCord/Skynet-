//Project Skynet 
#include <iostream>
#include <random>
#include <ctime>

using namespace std;

//initialize grid searchg of 8x8

int main() {
	//declaring srand
	srand(time(0));
	//setting target location to a random number between 1-64
	int targetLocation = (rand() % 64) + 1;
	//declaring variables 
	int lowTargetRange = 1, highTargetRange = 64, guessTarget = 0;

	//display information of target
	cout << "Location of Enemy: " << targetLocation << endl;
	//do while loop
	do {
		//if target # is too high
		guessTarget = ((highTargetRange - lowTargetRange) / 2) + lowTargetRange;
		if (guessTarget > targetLocation) {
			cout << "Target not located parameters set too high: Hypothesis location: " << guessTarget << endl;
			highTargetRange = guessTarget - 1;
		}
		//else too low 
		else if (guessTarget < targetLocation) {
			cout << "Target not located parameters set too low: Hypothesis location: " << guessTarget << endl;
			lowTargetRange = guessTarget + 1;
		}
		else {
			continue;
		}
	} while (guessTarget != targetLocation);
	//once executed and number is found, display to user information
	cout << "Target located: Sending armament units, inbound in five minutes for extermination" << endl;

	system("pause");

	return 0;
}
 