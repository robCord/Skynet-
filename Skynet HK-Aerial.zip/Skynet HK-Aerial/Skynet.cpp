//Project Skynet 
#include <iostream>
#include <random>
#include <ctime>

using namespace std;

//initialize grid searchg of 8x8

int main() {
	srand(time(0));

	int targetLocation = (rand() % 64) + 1;

	int lowTargetRange = 1, highTargetRange = 64, guessTarget = 0;


	cout << "Location of Enemy: " << targetLocation << endl;
	do {
		guessTarget = ((highTargetRange - lowTargetRange) / 2) + lowTargetRange;
		if (guessTarget > targetLocation) {
			cout << "Guess is too high. Guess was: " << guessTarget << endl;
			highTargetRange = guessTarget - 1;
		}
		else if (guessTarget < targetLocation) {
			cout << "Guess is too low. Guess was: " << guessTarget << endl;
			lowTargetRange = guessTarget + 1;
		}
		else {
			continue;
		}
	} while (guessTarget != targetLocation);

	cout << "Found the target!" << endl;

	system("pause");

	return 0;
}
 